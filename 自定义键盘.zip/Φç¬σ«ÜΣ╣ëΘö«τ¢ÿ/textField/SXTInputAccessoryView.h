//
//  SXTInputAccessoryView.h
//  textField
//
//  Created by 大欢 on 16/2/18.
//  Copyright © 2016年 大欢. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SXTInputAccessoryView : UIView

@end
