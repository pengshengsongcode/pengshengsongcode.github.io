//
//  ViewController.m
//  textField
//
//  Created by 大欢 on 16/2/18.
//  Copyright © 2016年 大欢. All rights reserved.
//

#import "ViewController.h"
#import "SXTInputView.h"
#import "SXTInputAccessoryView.h"
#import "SXTNumberView.h"

@interface ViewController ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (strong, nonatomic) IBOutlet SXTInputView *inputView;
@property (strong, nonatomic) IBOutlet SXTInputAccessoryView *inputAccessoryView;

@end

@implementation ViewController

- (IBAction)keyBoardDown:(id)sender {
    
    [self.textField endEditing:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.textField.inputView = self.inputView;
    self.textField.inputAccessoryView = self.inputAccessoryView;
    
    [self configAction];
}

-(void)textFieldDidBeginEditing:(UITextField *)textField {
    
    [self configButton];
}

- (void)configAction {
    
    for (UIButton * btn in [self.inputView subviews]) {
        [btn addTarget:self action:@selector(inputAction:) forControlEvents:UIControlEventTouchUpInside];
    }
}

- (void)inputAction:(UIButton *)button {
    
    if ([button.currentTitle isEqualToString:@"ABC"]) {
        
        NSLog(@"%@",button.currentTitle);
        
    } else if ([button.currentTitle isEqualToString:@"delete"]) {
        
        if (self.textField.text.length == 0) {
            return;
        }
        
        NSMutableString * delete =  [NSMutableString stringWithString:self.textField.text] ;
        NSRange range = {delete.length - 1, 1};
        [delete deleteCharactersInRange:range];
        self.textField.text = delete;
        
    } else if ([button.currentTitle isEqualToString:@"·"]) {
        
        NSMutableString * add =  [NSMutableString stringWithString:self.textField.text] ;
        [add appendString:@"."];
        self.textField.text = add;
        
    } else {
        
        NSMutableString * add =  [NSMutableString stringWithString:self.textField.text] ;
        [add appendString:button.currentTitle];
        self.textField.text = add;
    }
    
}

- (void)configButton {
    
    NSArray * numberArray = [self randomArray];
    
    static NSInteger currentNumber = 0;
    
    for (id btn in [self.inputView subviews]) {
        
        if ([btn isKindOfClass:[SXTNumberView class]]) {
            
            SXTNumberView * numberView = (SXTNumberView *)btn;
            NSNumber * number = numberArray[currentNumber++];
            [numberView setTitle:[number stringValue]forState:UIControlStateNormal];
        }
    }
    
    currentNumber = 0;
    
}

-(NSArray *)randomArray
{

    NSMutableArray *startArray=[[NSMutableArray alloc] initWithObjects:@0,@1,@2,@3,@4,@5,@6,@7,@8,@9, nil];

    NSMutableArray *resultArray=[[NSMutableArray alloc] initWithCapacity:0];

    NSInteger m=10;
    
    for (int i = 0; i < m ; i++) {
        
        int temp = arc4random()%startArray.count;
        resultArray[i] = startArray[temp];
        startArray[temp] = [startArray lastObject];
        [startArray removeLastObject];
    }
    return resultArray;
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    [self.textField endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
